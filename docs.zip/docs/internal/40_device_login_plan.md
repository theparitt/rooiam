# Device Login — Design & Flow

Status: **PLAN** (not yet implemented). Date: 2026-06-02.

Cross-device authentication: a user logs in on a **web surface** (tenant portal
or the end-user hosted widget) by approving on a **trusted phone** running the
Rooiam mobile app (`rooiam-android`, later `rooiam-ios`).

This is the same idea as WhatsApp Web (QR), Microsoft Authenticator (number
match), and reverse-OTP (type a code).

---

## Surfaces (who is who)

| Surface | Role in device login |
|---|---|
| `rooiam-app` (tenant portal, web) | **Admin toggle**: a workspace owner enables/disables "Device login" as an allowed auth method for their workspace. Also a login surface itself. |
| Hosted login widget / `candycloud` (end-user, web) | **The web side**: shows the QR + number + 6-digit code and waits for approval. This is what the end user clicks. |
| `rooiam-android` (mobile, to build) | **The trusted authenticator**: a logged-in phone that scans the QR / picks the matching number / displays the 6-digit code. |
| `rooiam-server` | **The broker**: issues the challenge, brokers approval over Redis, issues the session on success. |

The phone is the root of trust: only a phone with a **valid Rooiam session**
(the user already signed in there once) can approve a new web login.

---

## The three methods (one challenge, three UX paths)

All three share ONE server-side challenge. The web shows all three at once; the
user picks whichever is convenient.

1. **QR scan → approve** — phone camera scans the QR, shows "Approve sign-in?",
   user taps approve.
2. **Number matching** — web shows one 2-digit number; phone shows three numbers;
   user taps the one matching the web. Defeats blind-approve phishing.
3. **Type a 6-digit code** — phone displays a 6-digit code; user types it into the
   web. Works without a camera; the web→phone direction is reversed.

---

## End-to-end flow

### A. Enable device login (admin, in rooiam-app)

1. Workspace owner opens **Access / login policy** in rooiam-app.
2. Toggles **"Allow device login"** ON for the workspace.
3. Stored in `organizations.allow_device_login` (new column), enforced by
   `shared/auth_policy.rs::ensure_auth_method_allowed()` like the other methods
   (magic link, passkey, google, microsoft). See [[feedback_no_fallback]].

### B. Register a trusted device (one-time, on the phone)

Before a phone can approve logins it must be enrolled as a trusted device.

1. User signs in to `rooiam-android` once (magic link / passkey / OAuth — the
   existing methods).
2. App calls `POST /v1/auth/device/register` with the phone's session →
   server stores a `trusted_devices` row (user_id, device_name, platform,
   push_token?, public_key?, created_at, last_seen).
3. The phone now holds a long-lived device credential (an opaque device token,
   or a device-bound keypair — see "Security" below).

### C. Web login via device

```
WEB (hosted widget / candycloud / rooiam-app)        ROOIAM-SERVER                 PHONE (rooiam-android)
  | click "Sign in with your phone"                       |                              |
  |--- POST /v1/auth/device/start ----------------------->|                              |
  |     { workspace_id, client_id?, surface }             | create challenge:            |
  |                                                        |  challenge_id (uuid)         |
  |                                                        |  web_number (2 digits)       |
  |                                                        |  decoy_numbers[2]            |
  |                                                        |  code (6 digits)             |
  |                                                        |  status=pending, ttl=120s    |
  |<-- { challenge_id, qr_payload, web_number, expires } --|  (Redis)                     |
  |  show QR + web_number + "code on your phone"           |                              |
  |                                                        |                              |
  |  --- poll: GET /v1/auth/device/status?challenge_id --->|                              |
  |  <-- { status: pending } (repeat ~2s, or SSE) ---------|                              |
  |                                                        |                              |
  |                                          (user scans QR with phone, OR opens app)     |
  |                                                        |<-- POST /device/approve -----|
  |                                                        |    { challenge_id,           |
  |                                                        |      chosen_number }  +device session
  |                                                        | verify:                      |
  |                                                        |  - device session valid      |
  |                                                        |  - device is trusted         |
  |                                                        |  - challenge pending & unexpired
  |                                                        |  - chosen_number==web_number |
  |                                                        |  - device user allowed in workspace
  |                                                        | mark status=approved,        |
  |                                                        |   bind user_id               |
  |                                                        |--- 200 approved ------------>|  phone shows "Done"
  |  --- next poll --->                                    |                              |
  |  <-- { status: approved } -----------------------------|                              |
  |        server Set-Cookie: session (the web is now logged in as the device's user)     |
  |  redirect to app / portal                              |                              |
```

**6-digit code variant (reverse direction):** the phone shows the `code`; the
user types it into the web; web calls `POST /v1/auth/device/code/verify
{ challenge_id, code }`; server checks it matches and the submitter is the
correct device-linked user → approved. Used when there's no camera.

---

## Server endpoints (new)

| Method | Path | Auth | Purpose |
|---|---|---|---|
| POST | `/v1/auth/device/start` | none (public, like magic-link/start) | Web starts a challenge; returns qr_payload, web_number, expires |
| GET | `/v1/auth/device/status` | none (channel-bound to challenge) | Web polls status (pending/approved/denied/expired). Prefer SSE/long-poll. |
| POST | `/v1/auth/device/approve` | **phone session** | Phone approves; must send chosen_number (number match) |
| POST | `/v1/auth/device/deny` | phone session | Phone rejects ("This wasn't me") |
| POST | `/v1/auth/device/code/verify` | none (channel-bound) | Web submits the 6-digit code shown on the phone |
| POST | `/v1/auth/device/register` | phone session | Enroll this phone as a trusted device |
| GET | `/v1/identity/me/devices` | session | List my trusted devices (for "My security") |
| DELETE | `/v1/identity/me/devices/{id}` | session | Revoke a trusted device |

All request/query DTOs use `#[serde(deny_unknown_fields)]` per the strict
contract. Reuse the existing `challenge_id` pattern from `modules/mfa`.

---

## Redis schema (the challenge)

Key: `device_login:{challenge_id}` (TTL 120s), value:
```
{
  "status": "pending" | "approved" | "denied" | "expired",
  "workspace_id": "...",
  "client_id": "...",            // optional, for hosted-widget/OIDC continuation
  "surface": "tenant" | "user",
  "web_number": 47,              // the number the WEB shows
  "decoy_numbers": [12, 91],     // shown on the phone alongside web_number
  "code": "284913",             // 6-digit, shown on the PHONE
  "web_channel": "<binding>",    // ties completion to the originating web client
  "approved_user_id": null,      // set on approve
  "created_at": "...",
  "ip": "...", "user_agent": "..."  // of the web that started it (for audit/risk)
}
```
Single-use: deleted (or status frozen) once approved/denied/consumed.

---

## Security model (this is auth — these are mandatory)

1. **Short TTL + single use.** ~120s. Approved challenge is consumed immediately
   when the web claims the session; cannot be replayed.
2. **Number matching beats blind approve.** The phone must send back the SAME
   number the web shows. A phishing site that proxies the QR can't predict which
   of the 3 numbers is correct, so the user catches it.
3. **Phone must be authenticated AND trusted.** `approve` requires a valid phone
   session whose user owns a `trusted_devices` row. A random app install cannot
   approve.
4. **Channel binding.** The web that called `start` is the only one that can
   complete the login (bind via a `web_channel` secret returned to the web and
   required on `status`/completion). Stops one browser starting a challenge that
   a different browser steals.
5. **Workspace policy enforced.** `approve` re-checks `allow_device_login` for the
   workspace via `auth_policy.rs` — disabling the method mid-flight blocks it.
6. **Rate limiting.** `start`, `approve`, `code/verify` rate-limited per IP and
   per user (reuse the existing rate-limit groups; add `ROOIAM_RATE_*_DEVICE`).
7. **Audit + risk signals.** Log `auth.device.challenge_started`,
   `auth.device.approved`, `auth.device.denied`, `auth.device.expired`. Feed the
   risk engine (new device, new IP) like other logins. "This wasn't me" (deny)
   raises a security alert.
8. **No silent fallback.** Missing/invalid challenge_id, wrong number, expired →
   explicit error, never a default. See [[feedback_no_fallback]].
9. **Redirect/continuation via DB, not client.** On approval the session is issued
   and the continuation (OIDC/widget) is resolved server-side, consistent with
   [[project_rooiam_widget_redirect_contract]] — the web does not supply the
   destination.

---

## Database (new)

```sql
-- migration: trusted devices
CREATE TABLE trusted_devices (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  device_name   TEXT NOT NULL,           -- "Theparitt's Pixel 8"
  platform      TEXT NOT NULL,           -- 'android' | 'ios'
  push_token    TEXT,                    -- for push-prompt later (FCM)
  public_key    TEXT,                    -- if device-bound keypair used
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_seen_at  TIMESTAMPTZ
);

-- migration: workspace policy flag
ALTER TABLE organizations ADD COLUMN allow_device_login BOOLEAN NOT NULL DEFAULT false;
```

---

## UI pieces (later)

- **rooiam-app** — Access page: a "Allow device login" toggle (next to magic
  link / passkey toggles).
- **Hosted widget / candycloud** — a "Sign in with your phone" button → shows a
  card with the QR, the big 2-digit number, and "or enter the 6-digit code from
  your app". Polls status; on approved, continues the login.
- **rooiam-android** (Kotlin + Jetpack Compose, start here) — sign in once;
  "Scan to sign in" camera screen; an approval prompt screen with
  number-match buttons; a screen that displays the rotating 6-digit code;
  a "Trusted devices" / revoke screen.

---

## Build order (recommended)

1. **Server first** (both web and phone need it):
   migrations → `trusted_devices` + `allow_device_login` → the `/auth/device/*`
   endpoints → Redis challenge → audit/risk/rate-limit wiring.
2. **rooiam-app** toggle for the workspace policy.
3. **Hosted widget** "Sign in with your phone" web UI (start + poll + the 3
   displays). Can be tested with a curl/Postman "phone" before the app exists.
4. **rooiam-android** the real authenticator.

Server is the foundation; everything else is a client of it.
