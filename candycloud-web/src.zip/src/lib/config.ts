const api = import.meta.env.VITE_API_URL?.trim()
const login = import.meta.env.VITE_LOGIN_URL?.trim()

export function getApiBase() {
  if (!api) {
    throw new Error('Missing VITE_API_URL. Set it to your Rooiam API base, for example http://localhost:5170/v1.')
  }
  return api.replace(/\/+$/, '')
}

export function getLoginBase() {
  if (!login) {
    throw new Error('Missing VITE_LOGIN_URL. Set it to your hosted Rooiam login host, for example http://localhost:5172. The demo will append /login-widget itself.')
  }
  return login.replace(/\/+$/, '')
}
