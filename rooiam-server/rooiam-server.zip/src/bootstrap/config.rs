use ipnet::IpNet;
use sqlx::{Connection, Executor};
use std::{env, fs};
use url::Url;

/// Server operating mode. Set via `ROOIAM_MODE`.
///
/// | Mode         | Demo seed | Demo-login route | 127.0.0.1 trusted proxy |
/// |--------------|-----------|-----------------|-------------------------|
/// | Production   | no        | no              | no                      |
/// | Demo         | yes       | yes             | no                      |
/// | Test         | no        | yes             | yes (for IP spoofing)   |
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum ServerMode {
    Production,
    Demo,
    Test,
}

impl ServerMode {
    /// Load from `ROOIAM_MODE`, falling back to legacy `ROOIAM_ENABLE_DEMO_SEED`.
    pub fn from_env() -> Self {
        let _ = dotenvy::dotenv();
        match env::var("ROOIAM_MODE")
            .unwrap_or_default()
            .trim()
            .to_ascii_lowercase()
            .as_str()
        {
            "demo" => return ServerMode::Demo,
            "test" => return ServerMode::Test,
            "production" | "prod" => return ServerMode::Production,
            _ => {}
        }
        // Legacy fallback
        let legacy = env::var("ROOIAM_ENABLE_DEMO_SEED")
            .unwrap_or_default()
            .trim()
            .to_ascii_lowercase();
        if matches!(legacy.as_str(), "1" | "true" | "yes" | "on") {
            ServerMode::Demo
        } else {
            ServerMode::Production
        }
    }

    pub fn label(&self) -> &'static str {
        match self {
            ServerMode::Production => "production",
            ServerMode::Demo => "demo",
            ServerMode::Test => "test",
        }
    }

    /// Whether the demo seed should run at startup.
    pub fn seed_on_startup(&self) -> bool {
        matches!(self, ServerMode::Demo)
    }

    /// Whether the `/v1/demo/login` endpoint is active.
    pub fn demo_routes_enabled(&self) -> bool {
        matches!(self, ServerMode::Demo | ServerMode::Test)
    }

    /// Whether `127.0.0.1` should be automatically added to trusted proxies.
    /// Enabled in test mode so `X-Forwarded-For` works without extra config.
    pub fn trust_localhost_proxy(&self) -> bool {
        matches!(self, ServerMode::Test)
    }
}

#[derive(Clone, Debug)]
pub struct AppConfig {
    pub mode: ServerMode,
    pub server: ServerConfig,
    pub database: DatabaseConfig,
    pub redis: RedisConfig,
    pub storage: StorageConfig,
    pub oauth: OAuthConfig,
    pub oidc: OidcConfig,
    pub webauthn: WebauthnConfig,
    pub rate_limit: RateLimitConfig,
}

#[derive(Clone, Debug)]
pub struct RateLimitConfig {
    /// Max requests per minute per endpoint in /auth/* (e.g. magic link send)
    pub auth_per_endpoint: u64,
    /// Max requests per minute per IP across all /auth/* endpoints
    pub auth_per_ip: u64,
    /// Max requests per minute per endpoint in /identity/* (e.g. /identity/me)
    pub identity_per_endpoint: u64,
    /// Max requests per minute per IP across all /identity/* endpoints
    pub identity_per_ip: u64,
    /// Max requests per minute per endpoint in /orgs/*
    pub orgs_per_endpoint: u64,
    /// Max requests per minute per IP across all /orgs/* endpoints
    pub orgs_per_ip: u64,
}

#[derive(Clone, Debug)]
pub struct ServerConfig {
    pub host: String,
    pub port: u16,
    pub issuer_url: String,
    pub frontend_url: String,
    pub admin_url: String,
    pub trusted_proxy_cidrs: Vec<IpNet>,
    /// Max logo upload size in bytes (default 8MB). Set via ROOIAM_MAX_LOGO_BYTES.
    pub max_logo_bytes: usize,
}

#[derive(Clone, Debug)]
pub struct DatabaseConfig {
    pub url: String,
}

#[derive(Clone, Debug)]
pub struct RedisConfig {
    pub url: String,
}

#[derive(Clone, Debug)]
pub struct StorageConfig {
    pub root: String,
    pub public_media_base: String,
}

#[derive(Clone, Debug)]
pub struct OAuthConfig {
    pub google_client_id: String,
    pub google_client_secret: String,
    pub microsoft_client_id: String,
    pub microsoft_client_secret: String,
    pub google_redirect_uri: String,
    pub microsoft_redirect_uri: String,
    pub microsoft_tenant_id: String,
    pub google_redirect_uri_explicit: bool,
    pub microsoft_redirect_uri_explicit: bool,
}

#[derive(Clone, Debug)]
pub struct OidcConfig {
    pub signing_secret: String,
    pub private_key_pem: Option<String>,
    pub public_key_pem: Option<String>,
    pub key_id: String,
}

#[derive(Clone, Debug)]
pub struct WebauthnConfig {
    pub rp_id: String,
    pub rp_name: String,
    pub origin: String,
    pub extra_origins: Vec<String>,
    pub allow_any_port: bool,
}

impl AppConfig {
    /// Validate required env vars and print clear errors. Call before `from_env()`.
    pub fn check_env() {
        let _ = dotenvy::dotenv();
        let required = vec![
            ("ROOIAM_DATABASE_URL", "PostgreSQL connection string, e.g. postgres://user:pass@host:5432/rooiam"),
        ];
        let mut missing = false;
        for (var, hint) in &required {
            match std::env::var(var) {
                Err(_) => {
                    eprintln!("  [ MISSING ]  {} — {}", var, hint);
                    missing = true;
                }
                Ok(val) if val.trim().is_empty() => {
                    eprintln!("  [ EMPTY   ]  {} — {}", var, hint);
                    missing = true;
                }
                _ => {}
            }
        }
        // Warn about optional but important vars
        let optional = [
            ("ROOIAM_REDIS_URL",    "Redis URL (default: redis://127.0.0.1:6379)"),
            ("ROOIAM_SMTP_HOST",    "SMTP host — email features will not work without this"),
        ];
        for (var, hint) in &optional {
            if std::env::var(var).map(|v| v.trim().is_empty()).unwrap_or(true) {
                eprintln!("  [ WARN    ]  {} not set — {}", var, hint);
            }
        }
        if missing {
            eprintln!();
            eprintln!("ERROR: Required environment variables are missing. Set them in .env or the environment.");
            std::process::exit(1);
        }
    }

    pub fn from_env() -> Self {
        let _ = dotenvy::dotenv(); // Load .env file silently

        tracing::info!("Loading configuration...");
        let mode = ServerMode::from_env();
        let database_url = resolve_database_url(&mode);
        std::env::set_var("ROOIAM_DATABASE_URL", &database_url);
        let port = env::var("ROOIAM_PORT")
            .unwrap_or_else(|_| "5170".to_string())
            .parse()
            .unwrap_or(5170);
        let default_issuer = format!("http://localhost:{}", port);
        let normalized_issuer = load_public_url(
            "ROOIAM_ISSUER_URL",
            default_issuer,
            PublicUrlDefault::Localhost,
        );
        let frontend_url = load_public_url(
            "ROOIAM_FRONTEND_URL",
            "http://localhost:5172".to_string(),
            PublicUrlDefault::Localhost,
        );
        let admin_url = load_public_url(
            "ROOIAM_ADMIN_URL",
            "http://localhost:5171".to_string(),
            PublicUrlDefault::Localhost,
        );
        let default_google_redirect = format!("{}/api/v1/auth/google/callback", normalized_issuer);
        let default_microsoft_redirect = format!("{}/api/v1/auth/microsoft/callback", normalized_issuer);

        let max_logo_bytes = env::var("ROOIAM_MAX_LOGO_BYTES")
            .ok()
            .and_then(|v| v.trim().parse::<usize>().ok())
            .unwrap_or(8 * 1024 * 1024); // default 8MB
        let storage_root = env_str("ROOIAM_STORAGE_ROOT",
            &format!("{}/.localdata/rooiam", env::current_dir().unwrap_or_else(|_| ".".into()).display()));
        let public_media_base = normalize_public_media_base(
            env_str("ROOIAM_PUBLIC_MEDIA_BASE", "/media")
        );

        let mut trusted_proxy_cidrs = load_trusted_proxy_cidrs();
        if mode.trust_localhost_proxy() {
            let localhost: IpNet = "127.0.0.1/32".parse().unwrap();
            if !trusted_proxy_cidrs.contains(&localhost) {
                trusted_proxy_cidrs.push(localhost);
            }
        }

        Self {
            mode: mode.clone(),
            server: ServerConfig {
                host: env_str("ROOIAM_HOST", "0.0.0.0"),
                port,
                issuer_url: normalized_issuer.clone(),
                frontend_url,
                admin_url,
                trusted_proxy_cidrs,
                max_logo_bytes,
            },
            database: DatabaseConfig {
                url: database_url,
            },
            redis: RedisConfig {
                url: env_str("ROOIAM_REDIS_URL", "redis://127.0.0.1:6379"),
            },
            storage: StorageConfig {
                root: storage_root,
                public_media_base,
            },
            oauth: OAuthConfig {
                google_client_id: env_str("ROOIAM_GOOGLE_CLIENT_ID", ""),
                google_client_secret: env_str("ROOIAM_GOOGLE_CLIENT_SECRET", ""),
                microsoft_client_id: env_str("ROOIAM_MICROSOFT_CLIENT_ID", ""),
                microsoft_client_secret: env_str("ROOIAM_MICROSOFT_CLIENT_SECRET", ""),
                google_redirect_uri: default_google_redirect,
                microsoft_redirect_uri: default_microsoft_redirect,
                microsoft_tenant_id: env::var("ROOIAM_MICROSOFT_TENANT_ID")
                    .unwrap_or_else(|_| "common".to_string()),
                google_redirect_uri_explicit: false,
                microsoft_redirect_uri_explicit: false,
            },
            oidc: OidcConfig {
                signing_secret: env::var("ROOIAM_OIDC_SIGNING_SECRET")
                    .ok()
                    .or_else(|| env::var("ROOIAM_JWT_SECRET").ok())
                    .filter(|value| !value.trim().is_empty())
                    .unwrap_or_else(|| format!("dev-oidc-signing-secret-{}", port)),
                private_key_pem: load_pem("ROOIAM_OIDC_PRIVATE_KEY_PEM", "ROOIAM_OIDC_PRIVATE_KEY_PATH"),
                public_key_pem: load_pem("ROOIAM_OIDC_PUBLIC_KEY_PEM", "ROOIAM_OIDC_PUBLIC_KEY_PATH"),
                key_id: env::var("ROOIAM_OIDC_KEY_ID")
                    .unwrap_or_else(|_| "rooiam-rs256-1".to_string()),
            },
            rate_limit: {
                // Production: strict limits.
                // Demo: production-like limits — real users clicking around, should feel real.
                // Test: effectively unlimited — automated scripts hammer endpoints rapidly.
                let (auth_ep, auth_ip, id_ep, id_ip, org_ep, org_ip) = match mode {
                    ServerMode::Test       => (u64::MAX, u64::MAX, u64::MAX, u64::MAX, u64::MAX, u64::MAX),
                    ServerMode::Production => (5, 20, 200, 600, 30, 100),
                    ServerMode::Demo       => (5, 20, 200, 600, 300, 1000),
                };
                RateLimitConfig {
                    auth_per_endpoint:      env_u64("ROOIAM_RATE_AUTH_PER_ENDPOINT",      auth_ep),
                    auth_per_ip:            env_u64("ROOIAM_RATE_AUTH_PER_IP",            auth_ip),
                    identity_per_endpoint:  env_u64("ROOIAM_RATE_IDENTITY_PER_ENDPOINT",  id_ep),
                    identity_per_ip:        env_u64("ROOIAM_RATE_IDENTITY_PER_IP",        id_ip),
                    orgs_per_endpoint:      env_u64("ROOIAM_RATE_ORGS_PER_ENDPOINT",      org_ep),
                    orgs_per_ip:            env_u64("ROOIAM_RATE_ORGS_PER_IP",            org_ip),
                }
            },
            webauthn: {
                let issuer_host = url::Url::parse(
                    &normalized_issuer
                )
                .ok()
                .and_then(|url| url.host_str().map(str::to_string))
                .unwrap_or_else(|| "localhost".to_string());

                let default_origin = if issuer_host == "localhost" {
                    "http://localhost:5171".to_string()
                } else {
                    normalized_issuer.clone()
                };

                WebauthnConfig {
                    rp_id: env::var("ROOIAM_WEBAUTHN_RP_ID")
                        .unwrap_or_else(|_| issuer_host.clone()),
                    rp_name: env::var("ROOIAM_WEBAUTHN_RP_NAME")
                        .unwrap_or_else(|_| "Rooiam".to_string()),
                    origin: env::var("ROOIAM_WEBAUTHN_ORIGIN")
                        .unwrap_or(default_origin)
                        .trim_end_matches('/')
                        .to_string(),
                    extra_origins: env::var("ROOIAM_WEBAUTHN_EXTRA_ORIGINS")
                        .unwrap_or_default()
                        .split(',')
                        .map(str::trim)
                        .filter(|value| !value.is_empty())
                        .map(str::to_string)
                        .collect(),
                    allow_any_port: env::var("ROOIAM_WEBAUTHN_ALLOW_ANY_PORT")
                        .map(|value| matches!(value.as_str(), "1" | "true" | "TRUE" | "yes" | "YES"))
                        .unwrap_or(issuer_host == "localhost"),
                }
            },
        }
    }

    pub async fn prepare_database(&self) -> anyhow::Result<()> {
        ensure_database_exists(&self.database.url).await
    }
}

fn resolve_database_url(mode: &ServerMode) -> String {
    let base = env::var("ROOIAM_DATABASE_URL")
        .ok()
        .filter(|value| !value.trim().is_empty())
        .unwrap_or_else(|| panic!("ROOIAM_DATABASE_URL is required. Set a full postgres URL like postgres://user:pass@host:5432/rooiam"));

    let target_db = match mode {
        ServerMode::Production => return base,
        ServerMode::Demo => "rooiam_demo",
        ServerMode::Test => "rooiam_test",
    };

    swap_database_name(&base, target_db)
}

fn swap_database_name(raw_url: &str, db_name: &str) -> String {
    let mut url = Url::parse(raw_url)
        .unwrap_or_else(|_| panic!("Invalid ROOIAM_DATABASE_URL. Use a full postgres URL like postgres://user:pass@host:5432/rooiam"));
    url.set_path(&format!("/{}", db_name));
    url.to_string()
}

async fn ensure_database_exists(database_url: &str) -> anyhow::Result<()> {
    let url = Url::parse(database_url)
        .unwrap_or_else(|_| panic!("Invalid ROOIAM_DATABASE_URL. Use a full postgres URL like postgres://user:pass@host:5432/rooiam"));
    let db_name = url.path().trim_start_matches('/').to_string();
    if db_name.is_empty() {
        anyhow::bail!("ROOIAM_DATABASE_URL is missing a database name");
    }

    let mut admin_url = url.clone();
    admin_url.set_path("/postgres");
    admin_url.set_query(None);
    admin_url.set_fragment(None);

    let mut conn = sqlx::postgres::PgConnection::connect(admin_url.as_str()).await?;
    let quoted_db = db_name.replace('"', "\"\"");
    let create_sql = format!("CREATE DATABASE \"{}\"", quoted_db);
    match conn.execute(create_sql.as_str()).await {
        Ok(_) => tracing::info!("Created database `{}` for current server mode.", db_name),
        Err(err) => {
            let message = err.to_string();
            let already_exists = message.contains("already exists")
                || message.contains("duplicate_database")
                || message.contains("42P04");
            if !already_exists {
                return Err(err.into());
            }
        }
    }
    Ok(())
}

fn load_trusted_proxy_cidrs() -> Vec<IpNet> {
    env::var("ROOIAM_TRUSTED_PROXY_CIDRS")
        .unwrap_or_default()
        .split(',')
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .map(|value| {
            value.parse::<IpNet>().unwrap_or_else(|_| {
                panic!(
                    "Invalid ROOIAM_TRUSTED_PROXY_CIDRS entry `{}`. Use CIDR values like `10.0.0.0/8` or `127.0.0.1/32`.",
                    value
                )
            })
        })
        .collect()
}

/// Read an env var and strip any trailing \r (Windows line endings from .env files).
fn env_str(key: &str, default: &str) -> String {
    std::env::var(key)
        .unwrap_or_else(|_| default.to_string())
        .trim_end_matches('\r')
        .to_string()
}

fn normalize_public_media_base(raw: String) -> String {
    let trimmed = raw.trim();
    if trimmed.is_empty() || trimmed == "/" {
        return "/media".to_string();
    }

    let mut normalized = if trimmed.starts_with('/') {
        trimmed.to_string()
    } else {
        format!("/{}", trimmed)
    };

    while normalized.len() > 1 && normalized.ends_with('/') {
        normalized.pop();
    }

    normalized
}

enum PublicUrlDefault {
    Localhost,
}

fn any_public_url_env_is_set() -> bool {
    ["ROOIAM_ISSUER_URL", "ROOIAM_FRONTEND_URL", "ROOIAM_ADMIN_URL"]
        .iter()
        .any(|key| env::var(key).map(|value| !value.trim().is_empty()).unwrap_or(false))
}

fn load_public_url(var: &str, fallback: String, default_kind: PublicUrlDefault) -> String {
    let raw = match env::var(var) {
        Ok(value) if !value.trim().is_empty() => value,
        Ok(_) => panic!("{} is set but empty. Use a full URL like https://auth.example.com", var),
        Err(_) if any_public_url_env_is_set() => {
            panic!(
                "{} is required when any public URL env is set. Set ROOIAM_ISSUER_URL, ROOIAM_FRONTEND_URL, and ROOIAM_ADMIN_URL together.",
                var
            )
        }
        Err(_) => match default_kind {
            PublicUrlDefault::Localhost => fallback,
        },
    };
    let trimmed = raw.trim();
    let parsed = Url::parse(trimmed)
        .unwrap_or_else(|_| panic!("Invalid {}. Use a full URL like https://auth.example.com", var));

    let mut normalized = parsed.to_string();
    while normalized.ends_with('/') {
        normalized.pop();
    }
    normalized
}


fn env_u64(key: &str, default: u64) -> u64 {
    std::env::var(key)
        .ok()
        .and_then(|v| v.trim().parse::<u64>().ok())
        .unwrap_or(default)
}

fn load_pem(value_var: &str, path_var: &str) -> Option<String> {
    if let Ok(value) = env::var(value_var) {
        if !value.trim().is_empty() {
            return Some(value);
        }
    }

    let path = env::var(path_var).ok()?;
    let content = fs::read_to_string(path).ok()?;
    if content.trim().is_empty() {
        None
    } else {
        Some(content)
    }
}
