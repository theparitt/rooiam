use sqlx::PgPool;
use url::Url;

use crate::bootstrap::config::AppConfig;
use crate::bootstrap::state::AppState;
use crate::shared::error::AppError;

#[derive(Clone, Debug, serde::Serialize)]
pub struct PublicUrls {
    pub issuer_url: String,
    pub frontend_url: String,
    pub admin_url: String,
}

pub async fn get_setting(db: &PgPool, key: &str) -> Result<Option<String>, AppError> {
    sqlx::query_scalar("SELECT value FROM system_settings WHERE key = $1")
        .bind(key)
        .fetch_optional(db)
        .await
        .map_err(|e| AppError::Internal(format!("Failed to load runtime setting '{}': {}", key, e)))
}

pub async fn effective_public_urls(
    db: &PgPool,
    config: &AppConfig,
) -> Result<PublicUrls, AppError> {
    Ok(PublicUrls {
        issuer_url: effective_public_url(db, "issuer_url", &config.server.issuer_url, "issuer_url").await?,
        frontend_url: effective_public_url(db, "frontend_url", &config.server.frontend_url, "frontend_url").await?,
        admin_url: effective_public_url(db, "admin_url", &config.server.admin_url, "admin_url").await?,
    })
}

pub async fn load_runtime_app_config(state: &AppState) -> Result<AppConfig, AppError> {
    let mut config = state.config.as_ref().clone();
    let public_urls = effective_public_urls(&state.db, &config).await?;

    config.server.issuer_url = public_urls.issuer_url.clone();
    config.server.frontend_url = public_urls.frontend_url.clone();
    config.server.admin_url = public_urls.admin_url.clone();

    if !config.oauth.google_redirect_uri_explicit {
        config.oauth.google_redirect_uri = format!(
            "{}/api/v1/auth/google/callback",
            config.server.issuer_url.trim_end_matches('/')
        );
    }

    if !config.oauth.microsoft_redirect_uri_explicit {
        config.oauth.microsoft_redirect_uri = format!(
            "{}/api/v1/auth/microsoft/callback",
            config.server.issuer_url.trim_end_matches('/')
        );
    }

    Ok(config)
}

pub async fn effective_frontend_url(db: &PgPool, config: &AppConfig) -> Result<String, AppError> {
    effective_public_url(db, "frontend_url", &config.server.frontend_url, "frontend_url").await
}

pub async fn effective_frontend_url_with_env_fallback(db: &PgPool) -> Result<String, AppError> {
    let fallback = explicit_public_url_env("ROOIAM_FRONTEND_URL")
        .unwrap_or_else(|| "http://localhost:5172".to_string());
    effective_public_url(db, "frontend_url", &fallback, "frontend_url").await
}

pub async fn effective_admin_url(db: &PgPool, config: &AppConfig) -> Result<String, AppError> {
    effective_public_url(db, "admin_url", &config.server.admin_url, "admin_url").await
}

pub async fn effective_admin_url_with_env_fallback(db: &PgPool) -> Result<String, AppError> {
    let fallback = explicit_public_url_env("ROOIAM_ADMIN_URL")
        .unwrap_or_else(|| "http://localhost:5171".to_string());
    effective_public_url(db, "admin_url", &fallback, "admin_url").await
}

fn any_public_url_env_is_set() -> bool {
    ["ROOIAM_ISSUER_URL", "ROOIAM_FRONTEND_URL", "ROOIAM_ADMIN_URL"]
        .iter()
        .any(|key| std::env::var(key).map(|value| !value.trim().is_empty()).unwrap_or(false))
}

fn explicit_public_url_env(var: &str) -> Option<String> {
    match std::env::var(var) {
        Ok(value) if !value.trim().is_empty() => Some(value.trim().to_string()),
        Ok(_) => Some(String::new()),
        Err(_) if any_public_url_env_is_set() => Some(String::new()),
        Err(_) => None,
    }
}

fn normalize_public_url(value: &str, label: &str) -> Result<String, AppError> {
    let trimmed = value.trim();
    if trimmed.is_empty() {
        return Err(AppError::Validation(format!(
            "Missing {}. Set it in the environment or setup wizard.",
            label
        )));
    }

    let parsed = Url::parse(trimmed)
        .map_err(|_| AppError::Validation(format!("Invalid {}. Use a full URL like https://auth.example.com", label)))?;

    Ok(parsed.to_string().trim_end_matches('/').to_string())
}

async fn effective_public_url(
    db: &PgPool,
    key: &str,
    fallback: &str,
    label: &str,
) -> Result<String, AppError> {
    if let Some(value) = get_setting(db, key).await? {
        if !value.trim().is_empty() {
            return normalize_public_url(&value, label);
        }
    }

    normalize_public_url(fallback, label)
}
