use serde::{Deserialize, Serialize};

const ADMIN_LIST_DEFAULT_PAGE_SIZE: i64 = 20;
const ADMIN_LIST_MAX_PAGE_SIZE: i64 = 100;

#[derive(Deserialize)]
pub(super) struct AdminListQuery {
    pub page: Option<i64>,
    pub page_size: Option<i64>,
    pub search: Option<String>,
    pub role: Option<String>,
    pub scope: Option<String>,
    pub action: Option<String>,
    pub date_from: Option<String>,
    pub date_to: Option<String>,
}

#[derive(Serialize)]
pub(super) struct PaginatedResponse<T> {
    pub items: Vec<T>,
    pub total: i64,
    pub page: i64,
    pub page_size: i64,
}

pub(super) fn normalize_page(query: &AdminListQuery) -> i64 {
    query.page.unwrap_or(1).max(1)
}

pub(super) fn normalize_page_size(query: &AdminListQuery) -> i64 {
    query.page_size
        .unwrap_or(ADMIN_LIST_DEFAULT_PAGE_SIZE)
        .clamp(1, ADMIN_LIST_MAX_PAGE_SIZE)
}

pub(super) fn normalize_search(query: &AdminListQuery) -> String {
    query.search.as_deref().unwrap_or("").trim().to_lowercase()
}
